import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../directory/directory.dart';

class WorkOrder {
  final String id;
  final String title;
  final String? workType;
  final String priority;
  final String status;
  final String? objectName;
  final bool recurring;
  WorkOrder({required this.id, required this.title, this.workType, required this.priority,
      required this.status, this.objectName, required this.recurring});
  factory WorkOrder.fromMap(Map<String, dynamic> m) {
    final obj = m['objects'];
    return WorkOrder(
      id: m['id'] as String,
      title: (m['title'] ?? '') as String,
      workType: m['work_type'] as String?,
      priority: (m['priority'] ?? 'normal') as String,
      status: (m['status'] ?? 'new') as String,
      objectName: obj is Map ? obj['name'] as String? : null,
      recurring: m['recurrence'] != null,
    );
  }
}

class RequestsRepo {
  final SupabaseClient _c = Supabase.instance.client;
  Future<List<WorkOrder>> list() async {
    final rows = await _c
        .from('work_orders')
        .select('id,title,work_type,priority,status,recurrence, objects(name)')
        .order('created_at', ascending: false);
    return (rows as List).map((e) => WorkOrder.fromMap(e as Map<String, dynamic>)).toList();
  }
  Future<void> create({required String companyId, required String title, String? description,
      String? workType, required String priority, String? objectId, required bool recurring}) async {
    await _c.from('work_orders').insert({
      'company_id': companyId, 'title': title, 'description': description, 'work_type': workType,
      'priority': priority, 'status': 'new', 'input_channel': 'button', 'object_id': objectId,
      'recurrence': recurring ? {'kind': 'regular'} : null, 'created_by': _c.auth.currentUser?.id,
    });
  }
}

const _ink = Color(0xFF1C1E22);
const _muted = Color(0xFF8A9098);
const _line = Color(0xFFE8EAED);
const _onBrand = Color(0xFF06342A);

BoxDecoration _card() => BoxDecoration(
    color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: _line));

String _statusLabel(String s) => const {
      'new': 'Новая', 'assigned': 'Назначена', 'in_progress': 'В работе',
      'done': 'Готово', 'cancelled': 'Отменена', 'overdue': 'Просрочено',
    }[s] ?? s;

List<Color> _statusColors(String s) {
  switch (s) {
    case 'in_progress':
    case 'assigned':
      return const [Color(0xFFFBF0D9), Color(0xFFA9790C)];
    case 'overdue':
      return const [Color(0xFFFBE8E8), Color(0xFFC24444)];
    case 'done':
    case 'cancelled':
      return const [Color(0xFFEAECEF), Color(0xFF6B7480)];
    default:
      return const [Color(0xFFE8F6F2), Color(0xFF249F88)];
  }
}

class RequestsTab extends StatefulWidget {
  const RequestsTab({super.key});
  @override
  State<RequestsTab> createState() => _RequestsTabState();
}

class _RequestsTabState extends State<RequestsTab> {
  final _repo = RequestsRepo();
  final _dir = DirectoryRepo();
  late Future<List<WorkOrder>> _future;
  String? _companyId;
  List<Obj> _objects = const [];
  @override
  void initState() {
    super.initState();
    _future = _repo.list();
    _dir.myCompanyId().then((v) { if (mounted) setState(() => _companyId = v); });
    _dir.objects().then((v) { if (mounted) setState(() => _objects = v); }).catchError((_) => <Obj>[]);
  }
  void _reload() { if (mounted) setState(() => _future = _repo.list()); }
  @override
  Widget build(BuildContext context) {
    final brand = Theme.of(context).colorScheme.primary;
    return Stack(children: [
      RefreshIndicator(
        onRefresh: () async { _reload(); await _future; },
        child: FutureBuilder<List<WorkOrder>>(
          future: _future,
          builder: (context, snap) {
            if (snap.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snap.hasError) {
              return ListView(children: [_Msg(text: 'Не удалось загрузить заявки:\n${snap.error}', error: true)]);
            }
            final list = snap.data ?? [];
            if (list.isEmpty) {
              return ListView(children: const [
                SizedBox(height: 120),
                _Msg(text: 'Пока нет заявок.\nНажми «Создать заявку».'),
              ]);
            }
            return ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 140),
              itemCount: list.length + 1,
              itemBuilder: (_, i) {
                if (i == 0) {
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Text('Заявок: ${list.length}',
                        style: const TextStyle(color: _muted, fontWeight: FontWeight.w600, fontSize: 13)));
                }
                final w = list[i - 1];
                final c = _statusColors(w.status);
                final high = w.priority == 'high' || w.priority == 'critical';
                return Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.all(14),
                  decoration: _card(),
                  child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    Container(width: 6, decoration: BoxDecoration(
                        color: high ? const Color(0xFFC24444) : const Color(0xFFD7DBE0),
                        borderRadius: BorderRadius.circular(4))),
                    const SizedBox(width: 11),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(w.title + (w.recurring ? '  · регламент' : ''),
                          style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                      const SizedBox(height: 3),
                      Text('${w.objectName ?? 'Без объекта'}'
                          '${w.workType != null && w.workType!.isNotEmpty ? ' · ${w.workType}' : ''}',
                          style: const TextStyle(color: _muted, fontSize: 13)),
                    ])),
                    const SizedBox(width: 8),
                    Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(color: c[0], borderRadius: BorderRadius.circular(20)),
                        child: Text(_statusLabel(w.status),
                            style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: c[1]))),
                  ]),
                );
              },
            );
          },
        ),
      ),
      Positioned(
        right: 4, bottom: 8,
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.end, children: [
          FloatingActionButton.small(
            heroTag: 'refreshReq', backgroundColor: Colors.white, foregroundColor: brand,
            onPressed: _reload, child: const Icon(Icons.refresh)),
          const SizedBox(height: 10),
          FloatingActionButton.extended(
            heroTag: 'addReq', backgroundColor: brand, foregroundColor: _onBrand,
            onPressed: () => _openForm(context),
            icon: const Icon(Icons.add),
            label: const Text('Создать заявку', style: TextStyle(fontWeight: FontWeight.w800))),
        ]),
      ),
    ]);
  }
  Future<void> _openForm(BuildContext context) async {
    if (_companyId == null) { _snack('Профиль без компании (сделай себя админом).'); return; }
    final titleC = TextEditingController();
    final descC = TextEditingController();
    String? workType;
    String priority = 'normal';
    String? objectId;
    bool recurring = false;
    const workTypes = ['Сантехника', 'Электрика', 'Климат', 'Клининг', 'Мебель', 'Другое'];
    const priorities = [['low', 'Низкий'], ['normal', 'Обычный'], ['high', 'Высокий'], ['critical', 'Критич.']];
    final brand = Theme.of(context).colorScheme.primary;
    await showModalBottomSheet<void>(
      context: context, isScrollControlled: true, backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
        child: StatefulBuilder(
          builder: (ctx, setSt) => SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Center(child: Container(width: 40, height: 4, margin: const EdgeInsets.only(bottom: 14),
                    decoration: BoxDecoration(color: _line, borderRadius: BorderRadius.circular(4)))),
                const Text('Новая заявка', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
                _lbl('Что случилось?'),
                _inp(titleC, 'Например, Протекает кран'),
                _lbl('Описание'),
                _inp(descC, 'Подробности', lines: 3),
                _lbl('Объект'),
                _Dropdown(
                  value: objectId,
                  hint: _objects.isEmpty ? 'Нет объектов (добавь во вкладке Локации)' : 'Выбери объект',
                  items: [for (final o in _objects) DropdownMenuItem(value: o.id, child: Text(o.name))],
                  onChanged: (v) => setSt(() => objectId = v)),
                _lbl('Вид работ'),
                Wrap(spacing: 8, runSpacing: 8, children: [
                  for (final t in workTypes) _chip(t, workType == t, brand, () => setSt(() => workType = t))]),
                _lbl('Приоритет'),
                Wrap(spacing: 8, runSpacing: 8, children: [
                  for (final p in priorities) _chip(p[1], priority == p[0], brand, () => setSt(() => priority = p[0]))]),
                const SizedBox(height: 16),
                Row(children: [
                  const Expanded(child: Text('Регламентная (повторяющаяся)', style: TextStyle(fontSize: 15))),
                  Switch(value: recurring, activeColor: brand, onChanged: (v) => setSt(() => recurring = v))]),
                const SizedBox(height: 10),
                FilledButton(
                  style: FilledButton.styleFrom(backgroundColor: brand, foregroundColor: _onBrand),
                  onPressed: () async {
                    if (titleC.text.trim().isEmpty) { _snack('Впиши, что случилось'); return; }
                    try {
                      await _repo.create(companyId: _companyId!, title: titleC.text.trim(),
                          description: descC.text.trim().isEmpty ? null : descC.text.trim(),
                          workType: workType, priority: priority, objectId: objectId, recurring: recurring);
                      if (ctx.mounted) Navigator.pop(ctx);
                      _reload();
                      _snack('Заявка создана ✅');
                    } catch (e) { _snack('Ошибка: $e'); }
                  },
                  child: const Text('Создать заявку', style: TextStyle(fontWeight: FontWeight.w800))),
              ]),
            ),
          ),
        ),
      ),
    );
  }
  void _snack(String m) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m))); }
}

Widget _lbl(String t) => Padding(padding: const EdgeInsets.only(top: 16, bottom: 8),
    child: Text(t, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600, color: _ink)));

Widget _inp(TextEditingController c, String hint, {int lines = 1}) => TextField(
    controller: c, maxLines: lines,
    decoration: InputDecoration(hintText: hint,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
        contentPadding: const EdgeInsets.symmetric(horizontal: 15, vertical: 14)));

Widget _chip(String label, bool on, Color brand, VoidCallback onTap) => GestureDetector(onTap: onTap,
    child: Container(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
        decoration: BoxDecoration(color: on ? const Color(0xFFE8F6F2) : Colors.white,
            borderRadius: BorderRadius.circular(14), border: Border.all(color: on ? brand : _line)),
        child: Text(label, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700,
            color: on ? const Color(0xFF249F88) : _ink))));

class _Dropdown extends StatelessWidget {
  const _Dropdown({required this.value, required this.hint, required this.items, required this.onChanged});
  final String? value;
  final String hint;
  final List<DropdownMenuItem<String>> items;
  final ValueChanged<String?> onChanged;
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 15),
      decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), border: Border.all(color: _line)),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: value, isExpanded: true,
          hint: Text(hint, style: const TextStyle(color: _muted, fontSize: 15)),
          items: items, onChanged: items.isEmpty ? null : onChanged)));
  }
}

class _Msg extends StatelessWidget {
  const _Msg({required this.text, this.error = false});
  final String text;
  final bool error;
  @override
  Widget build(BuildContext context) => Center(
      child: Padding(padding: const EdgeInsets.all(28),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(error ? Icons.error_outline : Icons.assignment_outlined,
                size: 50, color: error ? const Color(0xFFC24444) : _muted),
            const SizedBox(height: 12),
            Text(text, textAlign: TextAlign.center,
                style: TextStyle(color: error ? const Color(0xFFC24444) : _muted)),
          ])));
}